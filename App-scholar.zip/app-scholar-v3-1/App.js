import React, { useState } from 'react';
import { StyleSheet, Text, Image, TouchableOpacity, View } from 'react-native';

// Importando as telas separadas de outros arquivos
import { AreaAlunos, FormAluno, ConsultarAlunos } from './pages/TelasAlunos';
import {
  AreaProfessores,
  FormProfessor,
  ConsultarProfessores,
} from './pages/TelasProfessores';
import {
  AreaCoordenadores,
  FormCoordenador,
  ConsultarCoordenadores,
} from './pages/TelasCoordenadores';
import {
  AreaMatriculas,
  FormMatricula,
  ConsultarMatriculas,
} from './pages/TelasMatriculas';
import { TelaOutro, TelaOutro2, TelaSobre } from './pages/TelasMenus';
import { AreaCursos, FormCurso, ConsultarCursos } from './pages/TelasCursos';

export default function App() {
  const [telaAtual, setTelaAtual] = useState('Home');

  // BANCOS DE DADOS SIMULADOS
  const [alunos, setAlunos] = useState([
    {
      id: '1',
      nome: 'Ana Souza',
      email: 'ana@escola.com',
      matricula: '202601',
      curso: 'Direito',
    },
    {
      id: '2',
      nome: 'Bruno Lima',
      email: 'bruno@escola.com',
      matricula: '202602',
      curso: 'Engenharia',
    },
  ]);
  const [professores, setProfessores] = useState([]);
  const [coordenadores, setCoordenadores] = useState([]);
  const [cursos, setCursos] = useState([]);
  const [matriculas, setMatriculas] = useState([]);

  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [matricula, setMatricula] = useState('');
  const [curso, setCurso] = useState('');
  const [alunoSelecionado, setAlunoSelecionado] = useState(null);

  const [nomeProf, setNomeProf] = useState('');
  const [emailProf, setEmailProf] = useState('');
  const [matriculaProf, setMatriculaProf] = useState('');
  const [departamentoProf, setDepartamentoProf] = useState('');
  const [professorSelecionado, setProfessorSelecionado] = useState(null);

  const [nomeCoord, setNomeCoord] = useState('');
  const [emailCoord, setEmailCoord] = useState('');
  const [matriculaCoord, setMatriculaCoord] = useState('');
  const [setorCoord, setSetorCoord] = useState('');
  const [coordenadorSelecionado, setCoordenadorSelecionado] = useState(null);

  const [nomeCurso, setNomeCurso] = useState('');
  const [cargaHoraria, setCargaHoraria] = useState('');
  const [duracao, setDuracao] = useState('');
  const [descricao, setDescricao] = useState('');
  const [cursoSelecionado, setCursoSelecionado] = useState(null);

  const [alunoMatricula, setAlunoMatricula] = useState('');
  const [cursoMatricula, setCursoMatricula] = useState('');
  const [situacaoMatricula, setSituacaoMatricula] = useState('');
  const [dataMatricula, setDataMatricula] = useState('');

  const [matriculaSelecionada, setMatriculaSelecionada] = useState(null);

  const [pesquisa, setPesquisa] = useState('');

  // LÓGICA: ALUNOS
  const lidarComCadastroAluno = () => {
    if (!nome || !email || !matricula || !curso) {
      alert('Aviso: Preencha todos os campos!');
      return;
    }
    setAlunos([
      ...alunos,
      { id: Math.random().toString(), nome, email, matricula, curso },
    ]);
    alert('Aluno cadastrado com sucesso!');
    limparCamposAluno('Alunos');
  };

  const iniciarEdicaoAluno = (aluno) => {
    setAlunoSelecionado(aluno);
    setNome(aluno.nome);
    setEmail(aluno.email);
    setMatricula(aluno.matricula);
    setCurso(aluno.curso);
    setTelaAtual('EditarAluno');
  };

  const salvarEdicaoAluno = () => {
    setAlunos(
      alunos.map((item) =>
        item.id === alunoSelecionado.id
          ? { ...item, nome, email, matricula, curso }
          : item
      )
    );
    alert('Dados updated!');
    limparCamposAluno('ConsultarAlunos');
  };

  const limparCamposAluno = (telaDestino) => {
    setNome('');
    setEmail('');
    setMatricula('');
    setCurso('');
    setAlunoSelecionado(null);
    setTelaAtual(telaDestino);
  };

  const alunosFiltrados = alunos.filter((aluno) =>
    aluno.nome.toLowerCase().includes(pesquisa.toLowerCase())
  );

  // LÓGICA: PROFESSORES
  const lidarComCadastroProf = () => {
    if (!nomeProf || !emailProf || !matriculaProf || !departamentoProf) {
      alert('Aviso: Preencha todos os campos!');
      return;
    }
    setProfessores([
      ...professores,
      {
        id: Math.random().toString(),
        nome: nomeProf,
        email: emailProf,
        matricula: matriculaProf,
        curso: departamentoProf,
      },
    ]);
    alert('Professor cadastrado com sucesso!');
    limparCamposProf('Professores');
  };

  const iniciarEdicaoProf = (prof) => {
    setProfessorSelecionado(prof);
    setNomeProf(prof.nome);
    setEmailProf(prof.email);
    setMatriculaProf(prof.matricula);
    setDepartamentoProf(prof.curso);
    setTelaAtual('EditarProfessor');
  };

  const salvarEdicaoProf = () => {
    setProfessores(
      professores.map((item) =>
        item.id === professorSelecionado.id
          ? {
              ...item,
              nome: nomeProf,
              email: emailProf,
              matricula: matriculaProf,
              curso: departamentoProf,
            }
          : item
      )
    );
    alert('Dados atualizados!');
    limparCamposProf('ConsultarProf');
  };

  const limparCamposProf = (telaDestino) => {
    setNomeProf('');
    setEmailProf('');
    setMatriculaProf('');
    setDepartamentoProf('');
    setProfessorSelecionado(null);
    setTelaAtual(telaDestino);
  };

  const professoresFiltrados = professores.filter((prof) =>
    prof.nome.toLowerCase().includes(pesquisa.toLowerCase())
  );

  // LÓGICA: COORDENADORES
  const lidarComCadastroCoord = () => {
    if (!nomeCoord || !emailCoord || !matriculaCoord || !setorCoord) {
      alert('Aviso: Preencha todos os campos!');
      return;
    }
    setCoordenadores([
      ...coordenadores,
      {
        id: Math.random().toString(),
        nome: nomeCoord,
        email: emailCoord,
        matricula: matriculaCoord,
        curso: setorCoord,
      },
    ]);
    alert('Coordenador cadastrado com sucesso!');
    limparCamposCoord('Coordenadores');
  };

  const iniciarEdicaoCoord = (coord) => {
    setCoordenadorSelecionado(coord);
    setNomeCoord(coord.nome);
    setEmailCoord(coord.email);
    setMatriculaCoord(coord.matricula);
    setSetorCoord(coord.curso);
    setTelaAtual('EditarCoordenador');
  };

  const salvarEdicaoCoord = () => {
    setCoordenadores(
      coordenadores.map((item) =>
        item.id === coordenadorSelecionado.id
          ? {
              ...item,
              nome: nomeCoord,
              email: emailCoord,
              matricula: matriculaCoord,
              curso: setorCoord,
            }
          : item
      )
    );
    alert('Dados atualizados!');
    limparCamposCoord('ConsultarCoord');
  };

  const limparCamposCoord = (telaDestino) => {
    setNomeCoord('');
    setEmailCoord('');
    setMatriculaCoord('');
    setSetorCoord('');
    setCoordenadorSelecionado(null);
    setTelaAtual(telaDestino);
  };

  const coordenadoresFiltrados = coordenadores.filter((coord) =>
    coord.nome.toLowerCase().includes(pesquisa.toLowerCase())
  );

  // ===============================
  // LÓGICA: CURSOS
  // ===============================

  const lidarComCadastroCurso = () => {
    if (!nomeCurso || !cargaHoraria || !duracao || !descricao) {
      alert('Aviso: Preencha todos os campos!');
      return;
    }

    if (descricao.length > 300) {
      alert('A descrição deve ter no máximo 300 caracteres!');
      return;
    }

    setCursos([
      ...cursos,
      {
        id: Math.random().toString(),
        nome: nomeCurso,
        cargaHoraria: cargaHoraria,
        duracao: duracao,
        descricao: descricao,
      },
    ]);

    alert('Curso cadastrado com sucesso!');

    limparCamposCurso('Cursos');
  };

  const iniciarEdicaoCurso = (curso) => {
    setCursoSelecionado(curso);

    setNomeCurso(curso.nome);
    setCargaHoraria(curso.cargaHoraria);
    setDuracao(curso.duracao);
    setDescricao(curso.descricao);

    setTelaAtual('EditarCurso');
  };

  const salvarEdicaoCurso = () => {
    setCursos(
      cursos.map((item) =>
        item.id === cursoSelecionado.id
          ? {
              ...item,
              nome: nomeCurso,
              cargaHoraria: cargaHoraria,
              duracao: duracao,
              descricao: descricao,
            }
          : item
      )
    );

    alert('Dados atualizados!');

    limparCamposCurso('ConsultarCursos');
  };

  const limparCamposCurso = (telaDestino) => {
    setNomeCurso('');
    setCargaHoraria('');
    setDuracao('');
    setDescricao('');
    setCursoSelecionado(null);

    setTelaAtual(telaDestino);
  };

  const cursosFiltrados = cursos.filter((curso) =>
    curso.nome.toLowerCase().includes(pesquisa.toLowerCase())
  );

  // =====================================================
  // LÓGICA: MATRÍCULAS
  // =====================================================

  // 1. CADASTRAR MATRÍCULA
  const lidarComCadastroMatricula = () => {
    if (
      !cursoMatricula ||
      !situacaoMatricula ||
      !dataMatricula
    ) {
      alert('Aviso: Preencha todos os campos!');
      return;
    }

    if (dataMatricula.length !== 10) {
      alert('Informe a data no formato DD/MM/AAAA!');
      return;
    }

    setMatriculas([
      ...matriculas,
      {
        id: Math.random().toString(),
        curso: cursoMatricula,
        situacao: situacaoMatricula,
        dataMatricula: dataMatricula,
      },
    ]);

    alert('Matrícula cadastrada com sucesso!');
    limparCamposMatricula('Matriculas');
  };

  // 2. INICIAR EDIÇÃO DA MATRÍCULA
  const iniciarEdicaoMatricula = (matricula) => {
    setMatriculaSelecionada(matricula);
    setCursoMatricula(matricula.curso);
    setSituacaoMatricula(matricula.situacao);
    setDataMatricula(matricula.dataMatricula);

    setTelaAtual('EditarMatricula');
  };

  // 3. SALVAR EDIÇÃO DA MATRÍCULA
  const salvarEdicaoMatricula = () => {
    if (
      !cursoMatricula ||
      !situacaoMatricula ||
      !dataMatricula
    ) {
      alert('Aviso: Preencha todos os campos!');
      return;
    }

    if (dataMatricula.length !== 10) {
      alert('Informe a data no formato DD/MM/AAAA!');
      return;
    }

    setMatriculas(
      matriculas.map((item) =>
        item.id === matriculaSelecionada.id
          ? {
              ...item,
              curso: cursoMatricula,
              situacao: situacaoMatricula,
              dataMatricula: dataMatricula,
            }
          : item
      )
    );

    alert('Dados atualizados!');

    limparCamposMatricula('ConsultarMatriculas');
  };

  // 4. LIMPAR CAMPOS DA MATRÍCULA
  const limparCamposMatricula = (telaDestino) => {
    setCursoMatricula('');
    setSituacaoMatricula('');
    setDataMatricula('');
    setMatriculaSelecionada(null);

    setTelaAtual(telaDestino);
  };

  // 5. FILTRAR MATRÍCULAS
  const matriculasFiltradas = matriculas.filter(
    (item) =>
      item.curso.toLowerCase().includes(pesquisa.toLowerCase()) ||
      item.situacao.toLowerCase().includes(pesquisa.toLowerCase()) ||
      item.dataMatricula.includes(pesquisa)
  );

  // ROTEAMENTO DINÂMICO CONDIÇIONAL
  if (telaAtual === 'Alunos')
    return <AreaAlunos setTelaAtual={setTelaAtual} setPesquisa={setPesquisa} />;
  if (telaAtual === 'CadAlunos' || telaAtual === 'EditarAluno') {
    return (
      <FormAluno
        telaAtual={telaAtual}
        nome={nome}
        setNome={setNome}
        email={email}
        setEmail={setEmail}
        matricula={matricula}
        setMatricula={setMatricula}
        curso={curso}
        setCurso={setCurso}
        salvarEdicaoAluno={salvarEdicaoAluno}
        lidarComCadastroAluno={lidarComCadastroAluno}
        setTelaAtual={setTelaAtual}
      />
    );
  }
  if (telaAtual === 'ConsultarAlunos')
    return (
      <ConsultarAlunos
        pesquisa={pesquisa}
        setPesquisa={setPesquisa}
        alunosFiltrados={alunosFiltrados}
        iniciarEdicaoAluno={iniciarEdicaoAluno}
        setTelaAtual={setTelaAtual}
      />
    );

  if (telaAtual === 'Professores')
    return (
      <AreaProfessores setTelaAtual={setTelaAtual} setPesquisa={setPesquisa} />
    );
  if (telaAtual === 'CadProf' || telaAtual === 'EditarProfessor') {
    return (
      <FormProfessor
        telaAtual={telaAtual}
        nomeProf={nomeProf}
        setNomeProf={setNomeProf}
        emailProf={emailProf}
        setEmailProf={setEmailProf}
        matriculaProf={matriculaProf}
        setMatriculaProf={setMatriculaProf}
        departamentoProf={departamentoProf}
        setDepartamentoProf={setDepartamentoProf}
        salvarEdicaoProf={salvarEdicaoProf}
        lidarComCadastroProf={lidarComCadastroProf}
        setTelaAtual={setTelaAtual}
      />
    );
  }
  if (telaAtual === 'ConsultarProf')
    return (
      <ConsultarProfessores
        pesquisa={pesquisa}
        setPesquisa={setPesquisa}
        professoresFiltrados={professoresFiltrados}
        iniciarEdicaoProf={iniciarEdicaoProf}
        setTelaAtual={setTelaAtual}
      />
    );

  if (telaAtual === 'Coordenadores')
    return (
      <AreaCoordenadores
        setTelaAtual={setTelaAtual}
        setPesquisa={setPesquisa}
      />
    );
  if (telaAtual === 'CadCoord' || telaAtual === 'EditarCoordenador') {
    return (
      <FormCoordenador
        telaAtual={telaAtual}
        nomeCoord={nomeCoord}
        setNomeCoord={setNomeCoord}
        emailCoord={emailCoord}
        setEmailCoord={setEmailCoord}
        matriculaCoord={matriculaCoord}
        setMatriculaCoord={setMatriculaCoord}
        setorCoord={setorCoord}
        setSetorCoord={setSetorCoord}
        salvarEdicaoCoord={salvarEdicaoCoord}
        lidarComCadastroCoord={lidarComCadastroCoord}
        setTelaAtual={setTelaAtual}
      />
    );
  }
  if (telaAtual === 'ConsultarCoord')
    return (
      <ConsultarCoordenadores
        pesquisa={pesquisa}
        setPesquisa={setPesquisa}
        coordenadoresFiltrados={coordenadoresFiltrados}
        iniciarEdicaoCoord={iniciarEdicaoCoord}
        setTelaAtual={setTelaAtual}
      />
    );

  if (telaAtual === 'Cursos')
    return <AreaCursos setTelaAtual={setTelaAtual} setPesquisa={setPesquisa} />;

  if (telaAtual === 'CadCursos' || telaAtual === 'EditarCurso') {
    return (
      <FormCurso
        telaAtual={telaAtual}
        nomeCurso={nomeCurso}
        setNomeCurso={setNomeCurso}
        cargaHoraria={cargaHoraria}
        setCargaHoraria={setCargaHoraria}
        duracao={duracao}
        setDuracao={setDuracao}
        descricao={descricao}
        setDescricao={setDescricao}
        salvarEdicaoCurso={salvarEdicaoCurso}
        lidarComCadastroCurso={lidarComCadastroCurso}
        setTelaAtual={setTelaAtual}
      />
    );
  }

  if (telaAtual === 'ConsultarCursos')
    return (
      <ConsultarCursos
        pesquisa={pesquisa}
        setPesquisa={setPesquisa}
        cursosFiltrados={cursosFiltrados}
        iniciarEdicaoCurso={iniciarEdicaoCurso}
        setTelaAtual={setTelaAtual}
      />
    );

  if (telaAtual === 'Matriculas') {
  return (
    <AreaMatriculas
      setTelaAtual={setTelaAtual}
      setPesquisa={setPesquisa}
    />
  );
}

if (telaAtual === 'CadMatriculas' || telaAtual === 'EditarMatricula') {
  return (
    <FormMatricula
      telaAtual={telaAtual}
      aluno={alunoMatricula}
      setAluno={setAlunoMatricula}
      curso={cursoMatricula}
      setCurso={setCursoMatricula}
      situacao={situacaoMatricula}
      setSituacao={setSituacaoMatricula}
      dataMatricula={dataMatricula}
      setDataMatricula={setDataMatricula}
      salvarEdicaoMatricula={salvarEdicaoMatricula}
      lidarComCadastroMatricula={lidarComCadastroMatricula}
      setTelaAtual={setTelaAtual}
    />
  );
}

if (telaAtual === 'ConsultarMatriculas') {
  return (
    <ConsultarMatriculas
      pesquisa={pesquisa}
      setPesquisa={setPesquisa}
      matriculasFiltradas={matriculasFiltradas}
      iniciarEdicaoMatricula={iniciarEdicaoMatricula}
      setTelaAtual={setTelaAtual}
    />
  );
}

  if (telaAtual === 'Outro') return <TelaOutro setTelaAtual={setTelaAtual} />;
  if (telaAtual === 'Outro2') return <TelaOutro2 setTelaAtual={setTelaAtual} />;
  if (telaAtual === 'Sobre') return <TelaSobre setTelaAtual={setTelaAtual} />;

  // RENDERIZAÇÃO DA HOME SCREEN
  return (
    <View style={styles.container}>
      <Image source={require('./assets/logo.png')} style={styles.logo} />
      <Text style={styles.titulo}>APP Scholar</Text>
      <Text style={styles.subtitulo}>Sistema Acadêmico Mobile</Text>
      <TouchableOpacity
        style={styles.botao}
        onPress={() => setTelaAtual('Alunos')}>
        <Text style={styles.textoBotao}>Alunos</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.botao}
        onPress={() => setTelaAtual('Professores')}>
        <Text style={styles.textoBotao}>Professores</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.botao}
        onPress={() => setTelaAtual('Coordenadores')}>
        <Text style={styles.textoBotao}>Coordenadores</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.botao}
        onPress={() => setTelaAtual('Outro')}>
        <Text style={styles.textoBotao}>Outros</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.botao}
        onPress={() => setTelaAtual('Sobre')}>
        <Text style={styles.textoBotao}>Sobre</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
  },
  logo: { width: 150, height: 150, marginBottom: 20 },
  titulo: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#1565C0',
    textAlign: 'center',
  },
  subtitulo: {
    fontSize: 18,
    marginBottom: 40,
    color: '#666',
    textAlign: 'center',
    paddingHorizontal: 20,
  },
  botao: {
    width: '80%',
    backgroundColor: '#e01f29',
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    alignItems: 'center',
  },
  textoBotao: { fontSize: 18, fontWeight: 'bold', color: '#FFFFFF' },
});

/*
matriculas 	desenvolver

    Inserir:
      Data da matricula (possivelmente automatica?)
      situação

    Visualizar matriculas e editar (mesmo formato)

disciplinas 	desenvolver

    Inserir:
      Nome da disciplina
      Professor responsavel (checar do banco)
      Carga horaria
    
    Visualizar e editar no mesmo formato

turmas		desenvolver

    Inserir:
      Ano letivo
      Turno (manha, tarde ou noite [checkbox]?)
      Sala

    Visualizar e editar no mesmo formato

Avaliações	desenvolver

    Inserir:
      Descrição
      Data
      Valor (até 100)

    Visualizar e editar no mesmo formato

Boletins	desenvolver

    Inserir:
      Notas
      Média
      Situação Final
      Frequencia

    Visualizar e editar no mesmo formato geral.

*/
